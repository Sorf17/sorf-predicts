// This file is no longer used for providing data to the application.
// All data is now fetched from and managed by Firebase Firestore.
// You can use this file as a reference for data structures or for seeding the database.

import type { User, Match, Prediction, Ranking } from './types';

// Example User data. In the app, this is stored in the 'users' collection in Firestore.
export const mockUsers: User[] = [
  // @ts-ignore
  { id: 'user-1', username: 'AdminGamer', role: 'admin', score: 150, email: 'admin@example.com' },
  // @ts-ignore
  { id: 'user-2', username: 'LoLProdigy', role: 'user', score: 125, email: 'prodigy@example.com' },
];

// Example Match data. In the app, this is stored in the 'matches' collection in Firestore.
export const mockMatches: Match[] = [
  {
    id: 'match-1',
    teamA: 'T1',
    teamALogo: 'https://placehold.co/64x64.png',
    teamB: 'Gen.G',
    teamBLogo: 'https://placehold.co/64x64.png',
    matchDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
    status: 'upcoming',
  },
];

// Example Prediction data. In the app, this is stored in the 'predictions' collection in Firestore.
export const mockPredictions: Prediction[] = [
  { id: 'pred-1', userId: 'user-1', matchId: 'match-4', predictedWinner: 'teamA', predictedScore: '2-1' },
];

// Example Ranking data. Rankings are dynamically generated in the app based on user scores from Firestore.
export const mockRankings: Ranking[] = [
  // @ts-ignore
  { rank: 1, user: mockUsers[0], predictions: [mockPredictions[0]] },
];
