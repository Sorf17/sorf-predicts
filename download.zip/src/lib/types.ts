
import { Timestamp } from "firebase/firestore";

export interface Award {
  id: string;
  rank: number;
  title: string;
  date: Date | Timestamp;
}

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
  score: number;
  allTimeScore?: number;
  avatarUrl?: string;
  awards?: Award[];
}

export interface Team {
  id: string;
  name: string;
  shortName?: string;
  logoUrl: string;
  hasDarkLogo?: boolean;
}

export interface League {
  id: string;
  name: string;
  logoUrl?: string;
}

export interface Match {
  id: string;
  teamA: string;
  teamALogo: string;
  teamAShortName?: string;
  teamAHasDarkLogo?: boolean;
  teamB: string;
  teamBLogo: string;
  teamBShortName?: string;
  teamBHasDarkLogo?: boolean;
  matchDate: Date | Timestamp;
  status: 'upcoming' | 'live' | 'completed';
  series: 'Bo1' | 'Bo3' | 'Bo5';
  leagueId: string;
  leagueName: string;
  winner?: 'teamA' | 'teamB';
  score?: string; // e.g., "2-1"
  adminOverride?: boolean;
}

export interface Prediction {
  id: string;
  userId: string;
  matchId: string;
  predictedWinner: 'teamA' | 'teamB';
  predictedScore: string; // e.g., "2-1"
  pointsAwarded?: number;
  seasonId?: string;
}

export interface Ranking {
  rank: number;
  user: User;
  predictions: Prediction[];
  leagueScores?: { [leagueId: string]: number };
}

export interface SeasonRanking {
  rank: number;
  userId: string;
  username: string;
  score: number;
  leagueScores?: { [leagueId: string]: number };
}

export interface Season {
  id: string;
  name: string;
  createdAt: Timestamp;
  rankings: SeasonRanking[];
}
