
'use client';

import { useState, useEffect, createContext, useContext, useCallback, type FC, type ReactNode } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link, { type LinkProps } from 'next/link';

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Context to hold the global state for navigation warning
interface NavigationContextType {
  isDirty: boolean;
  setIsDirty: (isDirty: boolean) => void;
  confirmNavigation: (url: string) => void;
}

const NavigationWarningContext = createContext<NavigationContextType | undefined>(undefined);


// Provider component to wrap the app layout
export const NavigationWarningProvider: FC<{ children: ReactNode }> = ({ children }) => {
    const [isDirty, setIsDirty] = useState(false);
    const [showDialog, setShowDialog] = useState(false);
    const [nextUrl, setNextUrl] = useState<string | null>(null);
    const router = useRouter();

    const confirmNavigation = useCallback((url: string) => {
        if (isDirty) {
            setNextUrl(url);
            setShowDialog(true);
        } else {
            router.push(url);
        }
    }, [isDirty, router]);

    const handleConfirm = () => {
        if (nextUrl) {
            setIsDirty(false); // Disable warning to allow navigation
            router.push(nextUrl);
        }
        setShowDialog(false);
        setNextUrl(null);
    };

    const handleCancel = () => {
        setShowDialog(false);
        setNextUrl(null);
    };

    // Re-enable isDirty flag check after navigation is complete
    const pathname = usePathname();
    useEffect(() => {
       setIsDirty(false); // Reset dirty state on route change
    }, [pathname]);

    return (
        <NavigationWarningContext.Provider value={{ isDirty, setIsDirty, confirmNavigation }}>
            {children}
             <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                    <AlertDialogTitle>Вы уверены, что хотите уйти?</AlertDialogTitle>
                    <AlertDialogDescription>
                        У вас есть несохраненные прогнозы. Если вы покинете эту страницу, ваши изменения будут потеряны.
                    </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                    <AlertDialogCancel onClick={handleCancel}>Остаться</AlertDialogCancel>
                    <AlertDialogAction onClick={handleConfirm}>Покинуть страницу</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </NavigationWarningContext.Provider>
    );
};


// Hook for pages to signal they have unsaved changes
export const useNavigationWarning = (dirty: boolean) => {
    const context = useContext(NavigationWarningContext);

    if (!context) {
        console.warn("useNavigationWarning must be used within a NavigationWarningProvider");
        return;
    }
    const { setIsDirty } = context;

    useEffect(() => {
        setIsDirty(dirty);
    }, [dirty, setIsDirty]);

    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (dirty) {
                e.preventDefault();
                e.returnValue = ''; // For legacy browsers
            }
        };

        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
        };
    }, [dirty]);
};


// Custom Link component that uses the context
export const WarningLink: FC<LinkProps & { children: ReactNode; className?: string }> = ({ href, children, ...props }) => {
    const context = useContext(NavigationWarningContext);
    
    // Fallback to regular link if context is not available
    if (!context) {
        return <Link href={href} {...props}>{children}</Link>;
    }
    
    const { confirmNavigation } = context;

    const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        confirmNavigation(href.toString());
    };

    return (
        <a href={href.toString()} onClick={handleClick} {...props}>
            {children}
        </a>
    );
};
