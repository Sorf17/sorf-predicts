export const firebaseConfig = {
  "projectId": "lol-predict-ux1zj",
  "appId": "1:644287605710:web:2a5c073bdcb33800a8d99f",
  "apiKey": "AIzaSyDXpEkPdaz1xzzKPrSwYUF23MKdguUc_Fs",
  "authDomain": "lol-predict-ux1zj.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "644287605710"
};
